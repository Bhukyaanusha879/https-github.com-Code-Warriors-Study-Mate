import subprocess

# Executing streamlit ui

subprocess.run(["streamlit", "run", "1_💬_Ask_questions.py"], text=True)
